const express = require("express");
const app = express();
const path = require("path");
const mysql = require('mysql');
const bodyParser = require('body-parser');
const moment = require('moment');

app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

const cont = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: ''
});
cont.connect(function(err){
    if(err)
    {
        console.error('Error connecting to the database:', err);
    }
    console.log("Connected");
    cont.query("CREATE DATABASE Eval",function(err,result){
        if (err)
        {
            console.error('Error connecting to the database:', err);
        }
        console.log("Database created");
    });
});
var con=mysql.createConnection({
    host:"127.0.0.1",
    user:"root",
    password:"",
    database:"Eval"
});

con.connect((err) => {
    if (err) {
        console.error('Error connecting to the database:', err);
        process.exit(1);
    }
    console.log('Connected to the database');
    var sql="CREATE TABLE userData(userName varchar(255), emailID varchar(255), phoneNo int(11), password varchar(255), dateTime date)";
    con.query(sql,function(err,result)
    {
        if (err)
        {
            console.error(`Error executing query: ${err}`);
        }
        console.log("Table created");
    });
});


app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html'));
});

// CRUD operations

const executeQuery = (sql, values, res, successMessage) => {
    con.query(sql, values, (err, result) => {
        if (err) {
            console.error(`Error executing query: ${err}`);
            res.status(500).send('Internal Server Error');
        } else {
            console.log(successMessage);
            res.json({ message: successMessage });
        }
    });
};

// Create (Insert)
app.post('/create', (req, res) => {
    const { userName, emailId, phoneNo, password } = req.body;
    const dateTime = moment().format('YYYY-MM-DD HH:mm:ss');
    const sql = "INSERT INTO userData (userName, emailId, phoneNo, password, dateTime) VALUES (?, ?, ?, ?, ?)";
    const values = [userName, emailId, phoneNo, password, dateTime];
    executeQuery(sql, values, res, 'Record inserted successfully');
});

// Read (Select)
app.post('/search', function (req, res) {
    const emailId = req.body.emailId;

    con.query('SELECT * FROM userData WHERE emailId = ?', [emailId], function (err, result) {
        if (err) {
            console.error('Error executing search query:');
            console.error(err);
            res.status(500).send('Internal Server Error');
        } else {
            console.log(result);
            res.json(result);
        }
    });
});
// Update
app.post('/update', (req, res) => {
    const { emailId, newPassword } = req.body;
    const sql = "UPDATE userData SET password = ? WHERE emailId = ?";
    const values = [newPassword, emailId];
    executeQuery(sql, values, res, 'Record updated successfully');
});

// Delete
app.post('/delete', (req, res) => {
    const { emailId } = req.body;
    const sql = "DELETE FROM userData WHERE emailId = ?";
    executeQuery(sql, [emailId], res, 'Record deleted successfully');
});

app.listen(3000, () => {
    console.log("Running at Port 3000");
});

process.on('SIGINT', () => {
    console.log('Closing the database connection');
    con.end((err) => {
        if (err) {
            console.error(`Error closing the database connection: ${err}`);
        } else {
            console.log('Database connection closed');
        }
        process.exit();
    });
});
